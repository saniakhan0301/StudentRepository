package com.cg.StudentRepository.bean;

import org.springframework.stereotype.Component;

@Component
public class OTP {

	private String number;
	private String otp;
	private long expiryTime;
	
	public OTP() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OTP(String number, String otp, long expiryTime) {
		super();
		this.number = number;
		this.otp = otp;
		this.expiryTime = expiryTime;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public long getExpiryTime() {
		return expiryTime;
	}
	public void setExpiryTime(long expiryTime) {
		this.expiryTime = expiryTime;
	}
	@Override
	public String toString() {
		return "OTP [number=" + number + ", otp=" + otp + ", expiryTime=" + expiryTime + "]";
	}
	
	
}
