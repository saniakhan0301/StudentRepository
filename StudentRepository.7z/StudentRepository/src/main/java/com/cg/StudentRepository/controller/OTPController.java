package com.cg.StudentRepository.controller;


import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.StudentRepository.bean.OTP;
import com.twilio.sdk.TwilioRestClient;
import com.twilio.sdk.TwilioRestException;
import com.twilio.sdk.resource.factory.MessageFactory;
import com.twilio.sdk.resource.instance.Message;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

@RestController
public class OTPController {

	private Map<String, OTP> otpdata = new HashMap<>();
	private final static String ACCOUNT_SID="ACea03a39d514b4407d2adfe1453b2ac3d";
	private final static String AUTH_ID="46ad5e2ff8cca7fc1d840acd26ecac26";
	public static final String TWILIO_NUMBER = "19384440253";
	
	
	
	
	@RequestMapping(value= "/sendotp/{mobile}",method=RequestMethod.POST)
	public String sendOtp(@PathVariable("mobile") String mobile){
		System.out.println("0000");

		sendSMS(mobile);
		System.out.println("afermsg");
		return "OTP sent seccessfully";
	}
	
	public void sendSMS(String mobile) {
	    try {
	        TwilioRestClient client = new TwilioRestClient(ACCOUNT_SID, AUTH_ID);

	        OTP otp=new OTP();
			otp.setNumber(mobile);
			otp.setOtp(String.valueOf(((int)(Math.random()*(10000-1000)))+1000));
			otp.setExpiryTime(System.currentTimeMillis()+60000);
			System.out.println("1111");
			
	        // Build a filter for the MessageList
	        List<NameValuePair> params = new ArrayList<NameValuePair>();
	        params.add(new BasicNameValuePair("Body", "Your OTP is:"+otp.getOtp()));
	        params.add(new BasicNameValuePair("To", mobile)); //Add real number here
	        params.add(new BasicNameValuePair("From", TWILIO_NUMBER));

			System.out.println("2222");

	        MessageFactory messageFactory = client.getAccount().getMessageFactory();
			System.out.println("3333");

	        Message message = messageFactory.create(params);
			System.out.println("4444");
			
			
	        System.out.println(message.getSid());
	        
	    } 
	    catch (TwilioRestException e) {
	        System.out.println(e.getErrorMessage());
	    }
	}
	
}

	

