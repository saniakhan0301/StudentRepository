package com.cg.StudentRepository.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.StudentRepository.bean.Student;
import com.cg.StudentRepository.service.AdminService;
import com.cg.StudentRepository.service.StudentService;

@Controller
public class StudentController {

	@Autowired
	private StudentService studentservice;

	@Autowired
	private AdminService adminservice;

	String adminName = null;
	String username = null;
	
	//Long studentid;

	@RequestMapping("/")
	public String index() {
		return "index";
	}

	/*
	 * @RequestMapping(value = { "/home" }) public String
	 * login(@ModelAttribute("Admin") Admin a) { // a.setRole("admin"); //
	 * adminservice.addAdmin(a); return "login"; }
	 */

	 @RequestMapping(value = {"/home"}) 
	 public ModelAndView home(@ModelAttribute("Student") Student student) {
	  
	  return new ModelAndView("login", "student", student); }
	 
	 @RequestMapping(value = {"/success"}) 
	 public ModelAndView success(@ModelAttribute("Student") Student student, Map<String, Object> model) {
		 if(studentservice.addStudent(student) != null)
		 {
			 model.put("studentAdded", true);
			 model.put("studentid", student.getStudentid());	 
			 model.put("username", student.getUsername());
			 model.put("addNewStudent", false);
			 return new ModelAndView("signup", "Student", student); 
		 }
		 else
		 {
			 model.put("userAdded", false);
			 return new ModelAndView("signup", "Student", student);
		 }		 
	  }
	 
	@RequestMapping(value = "loginUser", method = RequestMethod.POST)
	public ModelAndView loginUser(@ModelAttribute("Student") Student student, Map<String, Object> model) {
		
		Student studentList = new Student();
		studentList = studentservice.validateStudent(student.getUsername(),student.getPassword());
		if(studentList!=null) 
		{
			model.put("InvalidUser", false);
			model.put("studentid", studentList.getStudentid());
			model.put("username", studentList.getUsername());
			return new ModelAndView("StudentLanding");
		}
		else
		{
			model.put("InvalidUser", true);
			return new ModelAndView("login");
		}
	}

	/*
	 * @RequestMapping(value = { "/index" }) public String
	 * aftrLogin(@ModelAttribute("Admin") Admin a) { // a.setRole("admin"); Admin ad
	 * = adminservice.searchById(a.getAdminId()); System.out.println(ad); if (ad !=
	 * null) { if (ad.getAdminPass().equals(a.getAdminPass()) &&
	 * ad.getAdminName().equals(a.getAdminName())) { if
	 * (a.getRole().equalsIgnoreCase("Admin")) return "AdminLanding"; } }
	 * 
	 * return "login"; }
	 */

	@RequestMapping(value = { "/admin" })
	public String showsuccess() {
		return "admin";
	}

	@RequestMapping(value = { "/signup" })
	public String signup(@ModelAttribute("Student") Student student,Map<String, Object> model) {
		model.put("addNewStudent", true);
		return "signup";
	}

	@RequestMapping(value= {"/forgotPassword"})
	public ModelAndView forgotPassword(@ModelAttribute("Student") Student student)
	{
		return new ModelAndView("forgotPassword");
	}
	
	@RequestMapping(value = "studentLogout", method = RequestMethod.GET)
	public ModelAndView userLogout(@ModelAttribute("Student") Student student) {
	    username = null;
	    return new ModelAndView("login", "student", student);
	}
	
	@RequestMapping(value = "viewProfile", method = RequestMethod.GET)
    public ModelAndView viewProfile(@RequestParam("studentid") Long studentid, Map<String, Object> model) {
        model.put("viewProfile", true);
        model.put("editProfile", false);
        model.put("studentid", studentid);
        Student student = studentservice.getStudentById(studentid);
        model.put("username", student.getUsername());
        return new ModelAndView("StudentLanding", "student", student);
    }
	
	@RequestMapping(value = "editProfile", method = RequestMethod.GET)
	public ModelAndView editProfile(@RequestParam("studentid") Long studentid ,@ModelAttribute("Student") Student student ,Map<String, Object> model) {
		model.put("viewProfile", false);
        model.put("editProfile", true);
        model.put("studentid", studentid);
        Student student1 = studentservice.getStudentById(studentid);
        model.put("username", student1.getUsername());
		return new ModelAndView("StudentLanding","Student1",student1);
	}
	
	@RequestMapping(value = "update", method=RequestMethod.POST)
	public ModelAndView update(@ModelAttribute("Student") Student student, @RequestParam(value="studentid",required = false) Long studentid, Map<String, Object> model) {
		model.put("viewProfile", false);	
		model.put("editProfile", false);
		model.put("studentid", studentid);
		studentservice.updateStudent(student.getEmail(), student.getMobile() , studentid);
		model.put("updateSuccess",true);
		model.put("username", student.getUsername());
		return new ModelAndView("StudentLanding","Student",student);		
	}
	
	/*
	 * @RequestMapping(value = {"/AdminLanding"}) public ModelAndView
	 * adminPage(@ModelAttribute("Admin") Admin admin, Map<String, Object> model) {
	 * model.put("adminName", adminName); return new ModelAndView("AdminLanding"); }
	 */
}
