package com.cg.StudentRepository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.StudentRepository.bean.Admin;

@Repository
public interface IAdminDao extends JpaRepository<Admin, Long>{
	
	@Query(value = "SELECT * FROM Admin u WHERE u.adminId = ?1",nativeQuery = true)
	public Admin searchById(Long adminId);
}
