package com.cg.StudentRepository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.StudentRepository.bean.Student;

@Repository
public interface IStudentDao extends JpaRepository<Student, Long>{
	
	@Query(value = "SELECT * FROM student s WHERE s.studentid = ?1",nativeQuery = true)
	public Student searchById(Long studentid);
	
	@Query(value = "SELECT * FROM student s WHERE s.username = ?1 AND s.password = ?2",nativeQuery = true)
	public Student validateStudent(String username,String password);
	
	@Query(value = "SELECT * FROM student s WHERE s.studentid = ?1",nativeQuery = true)
	public Student getStudentById(Long studentid);
	
	@Transactional
	@Query(value = "UPDATE student s SET s.email = ?1, s.mobile = ?2 where s.studentid = ?3",nativeQuery = true)
	@Modifying
	public void updateStudent(String email, String mobile, Long studentid);
	
}
