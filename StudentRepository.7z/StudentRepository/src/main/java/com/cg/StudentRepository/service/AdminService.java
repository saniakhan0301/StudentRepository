package com.cg.StudentRepository.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.StudentRepository.bean.Admin;
import com.cg.StudentRepository.dao.IAdminDao;


@Service
public class AdminService {
	
	@Autowired
	private IAdminDao admindao;
	
	public Admin addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return admindao.save(admin);
	}

	public Admin searchById(Long adminId) {
		// TODO Auto-generated method stub
		return admindao.searchById(adminId);
	}

}
