package com.cg.StudentRepository.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.StudentRepository.bean.Student;
import com.cg.StudentRepository.dao.IStudentDao;



@Service
public class StudentService{
	
	@Autowired
	IStudentDao studentdao;

	public Student addStudent(Student student) {
		return studentdao.save(student);
	}
	
	public Student validateStudent(String username,String password) {
		  return studentdao.validateStudent(username,password); 
	}
	
	public Student getStudentById(Long studentid) {
		return studentdao.getStudentById(studentid);
	}

	public void updateStudent(String email, String mobile, Long studentid) {
		studentdao.updateStudent(email, mobile, studentid);
	}
}
